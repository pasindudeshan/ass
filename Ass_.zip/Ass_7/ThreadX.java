class ThreadX extends Thread{
	Thread next;

	public ThreadX(Thread t)
	{
		next=t;
	}

	public void run(){

		if(next.isAlive()){
			System.out.println("Thread Still Alive");
		}
		else{
			System.out.println("Thread is not alive");
		}
	}
}
