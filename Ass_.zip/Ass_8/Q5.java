
import java.util.Scanner;


class Packet{
	
	private StringBuffer content;

	public Packet(){
		content = new StringBuffer();
	}

	public void enclosePacket(){

		synchronized(this){

			content.append("<<");

			try{
				wait(); //method tells the calling thread (Current thread) to give up the lock and go to sleep until some other thread enters the same monitor and calls notify() or notifyAll().
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}

			content.append(">> ");
		}
	}



	public void addPacketContent(String content){

		synchronized(this){

			this.content.append(content);

			try{
				Thread.sleep(1000); //The sleep() method is used to stop the execution of the current thread(whichever might be executing in the system) for a specific duration of the time and after that time duration gets over, the thread which is executing earlier starts to execute again.
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}

			notify(); //The notify() method is defined in the Object class, which is Java's top-level class. It's used to wake up only one thread that's waiting for an object, and that thread then begins execution.
		}


	}

	public String getContent(){
		return content.toString();
	}

	

}

class EnclosePacket extends Thread{
	Packet packet;

	public EnclosePacket(Packet packet){
		this.packet = packet;
	}


	@Override
	public void run(){
		packet.enclosePacket();
	}
}

class AddCPacketContent extends Thread{
	Packet packet;
	String content;

	public AddCPacketContent(Packet packet, String content){
		this.packet = packet;
		this.content = content;
	}


	@Override
	public void run(){
		packet.addPacketContent(this.content);
	}
}

public class Q5{
	
	public static void main(String[] args){

		Packet packet = new Packet();

		System.out.println("Enter Your Text: ");
		Scanner input = new Scanner(System.in);
		String content = input.nextLine();

		String[] contents = content.split(" "); //split method is used to separate word from string usin the parameter symbol

		for(String i : contents){

			EnclosePacket enclosePacket = new EnclosePacket(packet);
		
			AddCPacketContent addPacketContent = new AddCPacketContent(packet, i);
			
			enclosePacket.start();
			addPacketContent.start();

			try{
				enclosePacket.join(); //Join method in Java allows one thread to wait until another thread completes its execution. In simpler words, it means it waits for the other thread to die.
				addPacketContent.join();
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}
			System.out.println(packet.getContent());
		}

	}

}