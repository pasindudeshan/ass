import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Q6  extends KeyAdapter{
	
	private JPanel pnl;
	private JTextField txtfield;
	private JTextArea lbl;
	private String msg = " ";
	private JFrame frm;

	public Q6(){

		this.frm = new JFrame();
		this.pnl = new JPanel();
		this.txtfield = new JTextField();
		this.lbl = new JTextArea("snmp");

		//Set layout
		this.pnl.setLayout(new BorderLayout());

		//Add elements
		this.pnl.add(txtfield, BorderLayout.NORTH);
		this.pnl.add(lbl, BorderLayout.SOUTH);
		frm.add(pnl);

		frm.setSize(500,500);
		frm.setVisible(true);
		frm.setDefaultCloseOperation(3);

		this.txtfield.addKeyListener(this); //extends from key adapter but we need to use keyListener

	}


	public static void main(String[] args){
		new Q6();
	}


	@Override
	public void keyPressed(KeyEvent ke){
		
		//checking that the enker key is pressed
		if(ke.getKeyCode() == KeyEvent.VK_ENTER){
			this.msg += this.txtfield.getText();
			this.lbl.setText(msg + " ");
			this.txtfield.setText(" ");
		}
	}
}