public abstract class Drink {
	private int serialNo;
	private int sugarContent;
	private String description;
	
	public Drink(int serialNo, String description){
		this.serialNo = serialNo;
		this.description = description;
		this.sugarContent = 0;
	}
	
	@Override 
	public String toString(){
		return String.format("%d - %s and Suger Level: %d", serialNo, description, sugarContent);
	}
	
	public void increaseSugarContent(int sugarAmount){
		this.sugarContent +=sugarAmount;
	}
	
	public abstract String getIngrediants();
	
}