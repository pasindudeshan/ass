public class SeriesCalculator extends Thread {
	
	private int start;
	private int end;
	private int sum_return;
	
	public SeriesCalculator(int start, int end){
		
		this.start = start;
		this.end = end;
		
	}

	public int getSummation(){
		
		return this.sum_return;
	}
	
	
	public void run(){
		int sum = 0 ;
		for(int i = start ; i <= end ; i++){
		
			sum+= i;
		}
		
		sum_return = sum;
	}
}


