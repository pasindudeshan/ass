import java.awt.*;
import javax.swing.*;

class Q2 extends Canvas{
	private Color color = Color.RED;
	private int width = 80;
	private int height = 30;


	@Override
	public void paint(Graphics g){
		g.setColor(color);
		g.fillRect(100,100,width,height);

	}

	public void setColor(Color c){
		this.color = c;
	}

	public void doubleWidthHeight(){
		this.width *= 2;
		this.height *= 2;
	}



	public static void main(String[] args){

		JFrame frm = new JFrame("Shape Change");

		JPanel pnl = new JPanel();
		JButton btn = new JButton("Change");

		Q2 canvas = new Q2();
		
		pnl.setLayout(new BorderLayout());
		
		JPanel pnl1 = new JPanel();
		JPanel pnl2 = new JPanel();
		JPanel pnl3 = new JPanel();
		JPanel pnl4 = new JPanel();

		pnl1.setBackground(Color.BLACK);
		pnl2.setBackground(Color.BLACK);
		pnl3.setBackground(Color.BLACK);
		pnl4.setBackground(Color.BLACK);

		pnl.add(pnl1,BorderLayout.NORTH);
		pnl.add(pnl2,BorderLayout.SOUTH);
		pnl.add(pnl3,BorderLayout.WEST);
		pnl.add(pnl4,BorderLayout.EAST);
		pnl.add(canvas);

		btn.addActionListener( ae -> //using lamda expression or we can use separate class that implements ActionListener and overrid the actionPerformed method 
			//also need to pass canvas refference
			{
				canvas.setColor(Color.GREEN);
				canvas.doubleWidthHeight();
				canvas.repaint(); //if you want to repaint use the repaint method
			}

			);

		frm.add(pnl);
		frm.add(btn, BorderLayout.SOUTH);

		frm.setVisible(true);
		frm.setSize(500,500);
		frm.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


	}
}