import java.awt.*;
import javax.swing.*;

public class Q1{

	public static void main(String[] args){

		JFrame first = new JFrame("Welcome");
		
		JPanel panelFirst = new JPanel();
		panelFirst.setBounds(0,0,400,400);

		JButton button1 = new JButton("OK");
		JButton button2 = new JButton("Cancel");

		first.add(panelFirst);
		panelFirst.add(button1);
		panelFirst.add(button2);

		first.setSize(400, 400);
		first.setVisible(true);
		first.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
}