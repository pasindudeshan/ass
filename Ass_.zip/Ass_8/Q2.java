class Counter{

	private int count;
	private static int static_count;

	public synchronized void increase_count(){

		int c = count;
		System.out.println("Value of count: " + c);
		count = ++c;
		System.out.println("Increased to: " + count);
	}

	public synchronized void decrease_count(){

		int c = count;
		System.out.println("Value of count: " + c);
		count = --c;
		System.out.println("Decreased to: " + count);
	}

	public synchronized static void increase_static_count(){

		int sc = static_count;
		System.out.println("Value of static count: " + sc);
		static_count = ++sc;
		System.out.println("Increased to: " + static_count);
	}

	public synchronized static void decrease_static_count(){

		int sc = static_count;
		System.out.println("Value of static count: " + sc);
		static_count = --sc;
		System.out.println("Decreased to: " + static_count);
	}

	public synchronized int getCount(){
		return this.count;
	}

	public synchronized int getStaticCount(){
		return static_count;
	}


}

class Incrementer extends Thread{

	Counter counterObj;

	public Incrementer(Counter counterObj){
		this.counterObj = counterObj;
	}

	@Override
	public void run(){

		for(int i = 0 ; i < 10 ; i++){
			counterObj.increase_count();
			counterObj.increase_static_count();
		}
	}


}

class Decrementer extends Thread{

	Counter counterObj;

	public Decrementer(Counter counterObj){
		this.counterObj = counterObj;
	}

	@Override
	public void run(){

		for(int i = 0 ; i < 3 ; i++){
			counterObj.decrease_count();
			counterObj.decrease_static_count();
		}
	}
	
}

public class Q2{

	public static void main(String[] args){

		Counter counterObj = new Counter();

		Incrementer incrementObj = new Incrementer(counterObj);
		Decrementer decrementObj = new Decrementer(counterObj);

		//starting two threads
		incrementObj.start();
		decrementObj.start();

	}
}

