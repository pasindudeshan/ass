import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.util.Scanner;

public class TestProgram{
	public static void main(String[] args){
		try{
		String pattern = "yyyy-MM-dd";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		Date date1 = simpleDateFormat.parse("2014-05-31");
		
		String name, memberType = " ";
		int memberTypeNumber;
		double expense;
		char isMember;
		
		Scanner input = new Scanner(System.in);
		
		System.out.print("Enter the Customer name: ");
		name = input.nextLine();
		
		Customer customer1 = new Customer(name);
		
		System.out.print("Is customer a member(y/n): ");
		isMember = input.next().charAt(0); //to get a single character
		
		if(isMember == 'y'){
			customer1.setMember(true);
		
		
		
			System.out.println("\n-------Member Type--------\n ");
			System.out.println("\t1).Premium\n\t2).Gold\n\t3).Silver\n");

					
			if(customer1.isMember()){
			
				System.out.print("\nSelect Member Type(Enter number):");
				memberTypeNumber = input.nextInt();


				switch(memberTypeNumber){
					case 1 : 
						memberType = "Premium";
						break;
					case 2 :
						memberType = "Gold";
						break;
						
					case 3 : 
						memberType = "Silver";
						break;
						
					default :
						System.out.println("Invalid selection!!");
				}
			
			}
		}
		customer1.setMemberType(memberType);
		System.out.print("\nEnter the Service Expense: ");
		expense = input.nextDouble();
		
		
		Visit visit1 = new Visit(customer1.getName(), customer1.getMemberType(), date1);	
		visit1.setServiceExpense(expense);

		System.out.println("\n-------------------------------------------------");
		System.out.println("Customer Name : " + customer1.getName());
		System.out.println("Customer Type: " + customer1.getMemberType());
		System.out.println("Service Expense for Custoemer: " + visit1.getServiceExpense());
		System.out.println("After the Discount Total Expense: " + visit1.getTotalExpense());		
		
		/*
		Visit visit2 = new Visit("Deshan", "Premium", new Date());
		visit2.setServiceExpense(15000);

		System.out.println(visit2.getServiceExpense());
		System.out.println(visit2.getTotalExpense());
		
		Visit visit3 = new Visit("Gunawardana", "Silver", new Date());
		visit3.setServiceExpense(15000);

		System.out.println(visit3.getServiceExpense());
		System.out.println(visit3.getTotalExpense());
		*/
		} 
		catch(ParseException e){
			e.printStackTrace();
		}
	}
}
