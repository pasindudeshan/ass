public class ThreadExtended extends Thread{
	
	@Override
	public void run(){
		System.out.println("I am from ThreadExtended");
	}
}
