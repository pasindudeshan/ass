public class Q4Test {
	
	public static void main(String[] args){
		Q4 thread1 = new Q4();
		Q4 thread2 = new Q4();
		
		thread1.start();
		thread2.start();
	}
}
