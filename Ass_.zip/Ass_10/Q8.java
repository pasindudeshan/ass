import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Q7 extends JFrame{
	
	private JLabel lbl1;
	private JLabel lbl2;
	private JLabel lbl3;
	private JTextField txtField1;
	private JTextField txtField2;
	private JTextField txtField3;
	private JButton btn1;
	private JButton btn2;

	public Q7(){

		this.setLayout(new GridLayout(4,2));

		this.lb1 = new JLabel("Number 1");
		this.lb2 = new JLabel("Number 2");
		this.lb3 = new JLabel("Answer");
		this.txtField1 = new JTextField();
		this.txtField2 = new JTextField();
		this.txtField3 = new JTextField();
		this.btn1 = new JLabel("Add");
		this.btn2 = new JLabel("Clear");

		this.add(lbl1);
		this.add(txtField1);
		this.add(lbl2);
		this.add(txtField2);
		this.add(lbl3);
		this.add(txtField3);
		this.add(btn1);
		this.add(btn2);


		this.setSize(400,300);
		this.setVisible(true);
		this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);

	}


	public static void main(String[] args){
		new Q7();
	}
}