import java.awt.*;
import javax.swing.*;

public class Q2{

	public static void main(String[] args){

		JFrame first = new JFrame("First UI");
		JPanel panelFirst = new JPanel();

		panelFirst.setBounds(0,0,400,400);
		panelFirst.setLayout(null); //no Layout manager
		JLabel label1 = new JLabel("Name");
		JLabel label2 = new JLabel("Age");
		JLabel label3 = new JLabel("Password");
		

		JTextField field1 = new JTextField(20);
		JTextField field2 = new JTextField(20);
		JPasswordField field3 = new JPasswordField(20); //password class can set the symbol
		field3.setEchoChar('*');

		label1.setBounds(0,0,80,15);
		label2.setBounds(0,20,80,15);
		label3.setBounds(0,40,80,15);
		field1.setBounds(90, 0,200, 15 );
		field2.setBounds(90, 20,200, 15 );
		field3.setBounds(90, 40,200, 15 );

		first.add(panelFirst);
		panelFirst.add(label1);
		panelFirst.add(label2);
		panelFirst.add(label3);
		panelFirst.add(field1);
		panelFirst.add(field2);
		panelFirst.add(field3);

		first.setSize(400, 400);
		first.setVisible(true);
		first.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}
}