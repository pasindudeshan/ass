
public class TestMyTriangle{
	
	public static void main(String[] args){
		MyTriangle myTriangle = new MyTriangle(1,10, 4,5, 3,0);
	
		myTriangle.printType();
		System.out.println(myTriangle);
		
		MyTriangle myTriangle2 = new MyTriangle(1,10, 2,5, 3,0);
	
		myTriangle2.printType();
		System.out.println(myTriangle2);
		
		MyTriangle myTriangle3 = new MyTriangle(-4,2, 5,4,-5 ,2);
	
		myTriangle3.printType();
		System.out.println(myTriangle3);
		

	}
}