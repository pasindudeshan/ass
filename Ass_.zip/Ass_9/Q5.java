import javax.swing.*;
import java.awt.*;

class Q5{
	

	public Q5(){
		JFrame frm = new JFrame("Login");

		JPanel pnl = new JPanel(new GridLayout(3,2));


		JLabel lbl1 = new JLabel("Username");
		JLabel lbl2 = new JLabel("Password");

		JTextField txtf = new JTextField(10);
		JPasswordField passtxtf = new JPasswordField(10);
		passtxtf.setEchoChar('*');

		JButton btn1 = new JButton("Login");
		JButton btn2 = new JButton("Cancel");

		pnl.add(lbl1);
		pnl.add(txtf);

		pnl.add(lbl2);
		pnl.add(passtxtf);

		pnl.add(btn1);
		pnl.add(btn2);

		frm.add(pnl);

		frm.setSize(400,200);
		frm.setVisible(true);
		frm.setDefaultCloseOperation(frm.EXIT_ON_CLOSE);


	}


	public static void main(String[] args){
		new Q5();
	}
}