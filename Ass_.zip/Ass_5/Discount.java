public class Discount{
	
	private static double serviceDiscountPremium = 0.2;
	private static double serviceDiscountGold = 0.15;
	private static double serviceDiscountSilver = 0.1;
	
	public static double getServiceDiscountRate(String type){
		if(type == "Premium"){
			return serviceDiscountPremium;
		}
		else if(type == "Gold"){
			return serviceDiscountGold;
		}
		else if(type == "Silver"){
			return serviceDiscountSilver;
		}
		else{

			return 0;
		}
	}
}
