public class Q4 extends Thread{

	@Override
	public void run(){
		for(int i = 1 ; i <= 10 ; i++){
			System.out.println(i + " " + getName()); //calling thread class getName() method
			try{
				Thread.sleep(1000); //currently executing thread go to sleep (temporarily cease) for miliseconds
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}
		}
	}
}
