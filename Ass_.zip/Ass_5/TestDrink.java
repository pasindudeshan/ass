public class TestDrink extends Drink{
	
	@Override 
	public String getIngrediants(){
		return "Ingrediants: Orange, Suger, Colouring" ;
	}
	public TestDrink(int serialNo, String description){
		super(serialNo, description);
	}
	
	public static void main(String[] args){
		
		TestDrink drink = new TestDrink(11112222, "Orange flavour  Juice") ;
		System.out.println(drink);
		drink.increaseSugarContent(75);
		System.out.println(drink);
		System.out.println(drink.getIngrediants());
	}
}