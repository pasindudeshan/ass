
public class TestMyPoint{
	
	public static void main(String[] args){
		MyPoint myPoint = new MyPoint(4,5);
		System.out.println(myPoint.getX() + " , " + myPoint.getY());
		
		System.out.println(myPoint);
		
		System.out.println(myPoint.distance(7,9));
		
		MyPoint myPoint1 = new MyPoint(7,9);
		
		System.out.println(myPoint.distance(myPoint1));
	}
}