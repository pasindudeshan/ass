public class Q1_ii{
	
	public static void main(String[] args){

		int[] amounts = {23, 12 , 34 , 56, 43};
		int sum = 0 ;
	
		for(int i = 0 ; i < 10 ; i++ ){
			sum += amounts[i];
		}
		
		System.out.println(amounts);
		//ArrayIndexOutOfBoundsException gets occur
	}
}