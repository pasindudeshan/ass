import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Q7 extends JFrame{
	
	private JLabel lbl1;
	private JLabel lbl2;
	private JLabel lbl3;
	private JTextField txtField1;
	private JTextField txtField2;
	private JTextField txtField3;
	private JButton btn1;
	private JButton btn2;
	private double num1 , num2, result;

	public Q7(){

		this.setTitle("Simple Adder");
		this.setLayout(new GridLayout(4,2));

		this.lbl1 = new JLabel("Number 1");
		this.lbl2 = new JLabel("Number 2");
		this.lbl3 = new JLabel("Answer");
		this.txtField1 = new JTextField();
		this.txtField2 = new JTextField();
		this.txtField3 = new JTextField();
		this.btn1 = new JButton("Add");
		this.btn2 = new JButton("Clear");

		this.add(lbl1);
		this.add(txtField1);
		this.add(lbl2);
		this.add(txtField2);
		this.add(lbl3);
		this.add(txtField3);
		this.add(btn1);
		this.add(btn2);


		this.setSize(400,300);
		this.setVisible(true);
		this.setDefaultCloseOperation(this.EXIT_ON_CLOSE);

		this.btn1.addActionListener( ae -> { //using lambda expression
				this.num1 = Double.parseDouble(this.txtField1.getText());
				this.num2 = Double.parseDouble(this.txtField2.getText());
				this.result = this.num1 + this.num2;
				this.txtField3.setText(String.valueOf(result));
			}

		);

		this.btn2.addActionListener( ae -> { //using lambda expression
				this.txtField1.setText(" ");
				this.txtField2.setText(" ");
				this.txtField3.setText(" ");
			}

		);

	}


	public static void main(String[] args){
		new Q7();
	}
}