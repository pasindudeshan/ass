import java.awt.*;
import javax.swing.*;

class Q6{
	
	public Q6(){
		JFrame frm = new JFrame("FancyBox"); //set Title 

		frm.setLayout(new BorderLayout()); //set Layout

		JPanel pnl1 =new JPanel();
		JPanel pnl2 =new JPanel();
		JPanel pnl3 =new JPanel();
		JPanel pnl4 =new JPanel();
		JPanel pnl5 =new JPanel();
		JPanel pnl6 =new JPanel();

		JButton btn1 = new JButton("Start");
		JButton btn2 = new JButton("End");

		JLabel lbl1 = new JLabel("Select Language");
		JLabel lbl2 = new JLabel("Select Country");
		JLabel lbl3 = new JLabel("Welcome");

		JRadioButton jbtn1 = new JRadioButton("Java");
		JRadioButton jbtn2 = new JRadioButton("C");
		JRadioButton jbtn3 = new JRadioButton("C#");
		JRadioButton jbtn4 = new JRadioButton("Python");
		JRadioButton jbtn5 = new JRadioButton("PHP");

		//creating button group to group the radio button
		ButtonGroup jbtngGroup = new ButtonGroup();

		//add radio button to group
		jbtngGroup.add(jbtn1);
		jbtngGroup.add(jbtn2);
		jbtngGroup.add(jbtn3);
		jbtngGroup.add(jbtn4);
		jbtngGroup.add(jbtn5);

		String[] country_array = {"Sri Lanka", "India", "Pakistan", "Bangladesh"};

		JList<String> lst = new JList<String>(country_array); // adding String array to JList

		//set size of the panel on BorderLayout only height or width will change
		pnl1.setPreferredSize(new Dimension(400, 25)); //we need to use .sefPrefferedSize();
		pnl2.setPreferredSize(new Dimension(400, 25));
		pnl4.setPreferredSize(new Dimension(120, 200));
		pnl6.setPreferredSize(new Dimension(120, 200));
		
		//set Layout of the panels
		pnl1.setLayout(new BorderLayout());
		pnl2.setLayout(new BorderLayout());
		pnl3.setLayout(new BorderLayout());
		pnl4.setLayout(new GridLayout(6,1));
		pnl6.setLayout(new GridLayout(2,1));
		pnl5.setLayout(new FlowLayout(FlowLayout.CENTER,0,90)); 

		//add  panels to Frame
		frm.add(pnl1, BorderLayout.NORTH);
		frm.add(pnl2, BorderLayout.SOUTH);
		frm.add(pnl3, BorderLayout.CENTER);
		
		//add panel to panel3
		pnl3.add(pnl4, BorderLayout.WEST);
		pnl3.add(pnl5, BorderLayout.CENTER);
		pnl3.add(pnl6, BorderLayout.EAST);

		pnl1.add(btn1);
		pnl2.add(btn2);

		//add content to the center block
		pnl5.add(lbl3);

		//add content to center block WEST side
		pnl4.add(lbl1);
		pnl4.add(jbtn1);
		pnl4.add(jbtn2);
		pnl4.add(jbtn3);
		pnl4.add(jbtn4);
		pnl4.add(jbtn5);


		//add conten to center block EAST side
		pnl6.add(lbl2);
		pnl6.add(lst);

		
		pnl5.setBackground(Color.YELLOW);

	
		frm.setSize(800,250);
		frm.setVisible(true);
		frm.setDefaultCloseOperation(3);
		frm.setLocationRelativeTo(null);
	}


	public static void main(String[] args){

		new Q6(); 	
	}
}