public class SinThread extends Thread{
	
	private double degrees;
	private double radians;
	
	public SinThread(double degrees){
		this.degrees = degrees;
	}
	
	public double sinValue(){
	
		return radians;
	}
	
	@Override
	public void run(){
		radians =  Math.sin(Math.toRadians(degrees));
		if(isAlive()){
			System.out.println("Thread is Alive");
			
			
		}

	}
}
