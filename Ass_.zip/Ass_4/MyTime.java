
public class MyTime{
	
	private int hour;
	private int minute;
	private int second;
	
	public MyTime(){
		this.hour = 0;
		this.minute = 0;
		this.second = 0;
	}
	
	public MyTime(int hour, int minute , int second ){
		
		if((hour >= 0 && hour <= 23) && (minute >= 0 && minute <= 59) && (second >= 0 && second <=59)){
			this.hour = hour ;
			this.minute = minute;
			this.second = second;
		}
		else {
			System.out.println("Invalid hour, minute, Second");
		}
	}
	
	public void setTime(int hour , int minute, int second){
		
		if((hour >= 0 && hour <= 23) && (minute >= 0 && minute <= 59) && (second >= 0 && second <=59)){
			this.hour = hour ;
			this.minute = minute;
			this.second = second;
		}
		else {
			System.out.println("Invalid hour, minute, Second");
		}
	}
	
	public int getHour(){
		return hour;
	}
	
	public int getMinute(){
		return minute;
	}
	
	public int getSecond(){
		return second;
	}
	
	public void setHour(int hour){
		if(hour >= 0 && hour <= 23){
			this.hour = hour ;
			}
		else {
			System.out.println("Invalid Hour");
		}	
	}
	
	public void setMinute(int minute){

		if(minute >= 0 && minute <= 59){
			this.minute = minute;
		}
		else {
			System.out.println("Invalid Minute");
		}
	}
	
	public void setSecond(int second){

		if(second >= 0 && second <=59){
			this.second = second;
		}
		else {
			System.out.println("Invalid Second");
		}
	}
	
	@Override
	public String toString(){
		return String.format("%d : %d : %d", hour, minute, second);
	}
	
	//A method can have the class name as its return type. Therefore it must return the object of the exact class or its subclass.
	public MyTime nextSecond(){
		if(getSecond() == 59 && getMinute() == 59 && getHour() == 23){
			setTime(0, 0, 0);
		}
		else if(getSecond() == 59 && getMinute() == 59){
			setSecond(0);
			setMinute(0);
			setHour( getHour() + 1);
		}
		else if(getSecond() == 59){
			setSecond(0);
			setMinute(getMinute() + 1);
		}else{
			setSecond(getSecond() + 1);
		}
		
		return (new MyTime(getHour(), getMinute(), getSecond()));
	}
	
	public MyTime nextMinute(){

		
		if(getHour() == 23 && getMinute() == 59){
			setMinute(0);
			setHour(0);
		}
		else if(getMinute() == 59){
			setMinute(0);
			setHour(getHour() + 1);
		}else{
			setMinute(getMinute() + 1);
		}
		
		return (new MyTime(getHour(), getMinute(), getSecond()));
	}
	
	public MyTime nextHour(){
		
		if(getHour() == 23){
			setHour(0);
		}else{
			setHour(getHour() + 1);
		}
		return (new MyTime(getHour(), getMinute(), getSecond()));		
	}
	
	public MyTime previousSecond(){
		if(getSecond() == 0 && getMinute() == 0 && getHour() == 0){
			setTime(23, 59, 59);
		}
		else if(getSecond() == 0 && getMinute() == 0){
			setSecond(59);
			setMinute(59);
			setHour( getHour() - 1);
		}
		else if(getSecond() == 0){
			setSecond(59);
			setMinute(getMinute() - 1);
		}else{
			setSecond(getSecond() - 1);
		}
		
		return (new MyTime(getHour(), getMinute(), getSecond()));
	}
	
		public MyTime previousMinute(){

		
		if(getHour() == 0 && getMinute() == 0){
			setMinute(59);
			setHour(23);
		}
		else if(getMinute() == 0){
			setMinute(59);
			setHour(getHour() - 1);
		}else{
			setMinute(getMinute() - 1);
		}
		
		return (new MyTime(getHour(), getMinute(), getSecond()));
	}
	
	public MyTime previousHour(){
		
		if(getHour() == 0){
			setHour(23);
		}else{
			setHour(getHour() - 1);
		}
		return (new MyTime(getHour(), getMinute(), getSecond()));		
	}
	
	
}