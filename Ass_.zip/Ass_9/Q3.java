import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

//List Demo
class Q3{

	public Q3(){

		Frame  frm = new Frame("Type of Lists");

		frm.addWindowListener(new WindowAdapter(){
				@Override
				public void windowClosing(WindowEvent e){
					frm.dispose(); //closing the Frame window only 
		//			System.exit(0); //will terminate every process in JVM
				}
			}

		);

		Panel aPanel = new Panel();

		frm.add(aPanel);

		Label country = new Label("Country");

		List country_list = new List();
		country_list.add("Sri Lanka");
		country_list.add("India");
		country_list.add("England");
		country_list.add("Australia");

		country_list.setMultipleMode(true); // can select multiples from the list

		Label sport = new Label("Sports");

		Choice aSport = new Choice();// The object of Choice class is used to show popup menu of choices.

		aSport.add("Cricket");
		aSport.add("FootBall");
		aSport.add("Chess");
		aSport.add("Swimming");

		aPanel.add(country);
		aPanel.add(country_list);

		aPanel.add(sport);
		aPanel.add(aSport);

		frm.setSize(400,200);
		frm.setVisible(true);

	}

	public static void main(String[] args){
		new Q3();
	}
}