public class Q1{
	
	public static void main(String[] args){
		ThreadExtended threadExtended = new ThreadExtended();
		ThreadRunnable threadRunnable = new ThreadRunnable();
		
		threadExtended.start();
		
		//Need to cread Thread class and pass the runnble interface implemeted object as an argumnets and then invoke the start method 
		Thread thread = new Thread(threadRunnable);
		thread.start();
	}
}
