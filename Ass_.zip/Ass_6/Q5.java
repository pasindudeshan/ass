
import java.util.Scanner;
import java.util.InputMismatchException;

public class Q5{
		
		public static void main(String[] args){
			try{
				Scanner input = new Scanner(System.in);
				System.out.println("Enter two integer values: ");
				int num1 = input.nextInt();
				int num2 = input.nextInt();
			
				System.out.println("Summation of Two numbers: " + (num1 + num2));
			}catch(InputMismatchException e){
				throw new InputMismatchException("Invalid type of input !! " + e.getMessage());
			}
		}
}
