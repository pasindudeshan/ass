
class Student{

	private String name;
	private int age;

	public Student(String name, int age){
		this.name = name;
		this.age = age;
	}


	public String getName(){
		return this.name;
	}

	public int getAge(){
		return this.age;
	}

}

class StudentThread extends Thread{
	private Student student1;
	private Student student2;

	public StudentThread(Student student1, Student student2){
		this.student1 = student1;
		this.student2 = student2;
	}


	public void run(){


		synchronized(student1){
			System.out.println(Thread.currentThread().getName()+ ": Holding the lock of:" + student1.getName());	
			try{
				Thread.sleep(100);
			}		
			catch(InterruptedException e){
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread().getName()+ ": Waiting for the lock of:" + student2.getName());	

			synchronized(student2){
				System.out.println(Thread.currentThread().getName()+ ": Holding the lock of:" + student2.getName());	
			}		
		}
	}
}

class Q7{

	public static void main(String[] args){
		Student s1 = new Student("John", 23);
		Student s2 = new Student("Mary", 22);

		StudentThread st1 = new StudentThread(s1,s2);
		st1.setName("First");
		StudentThread st2 = new StudentThread(s2,s1);
		st2.setName("Second");

		st1.start();
		st2.start();
	}
}
