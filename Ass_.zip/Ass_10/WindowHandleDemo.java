import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class WindowHandleDemo extends JFrame implements WindowListener{
	
	public WindowHandleDemo(){
		this.addWindowListener(this);
		this.setSize(400,400);
		this.setVisible(true);
	}

	@Override
	public void windowActivated(WindowEvent e){
		System.out.println("activated"); when opended and activate the window(used)
	}

		@Override
	public void windowClosed(WindowEvent e){
		System.out.println("closed"); 
	}

		@Override
	public void windowClosing(WindowEvent e){
		System.out.println("closing"); //when closing
	}

		@Override
	public void windowDeactivated(WindowEvent e){
		System.out.println("deactivated"); //when not is used ..click some other window
	}

		@Override
	public void windowDeiconified(WindowEvent e){
		System.out.println("deiconfied"); //when maximizing
	}

		@Override
	public void windowIconified(WindowEvent e){
		System.out.println("iconfied"); // when minimizing
	}

		@Override
	public void windowOpened(WindowEvent e){
		System.out.println("opened"); //when opened
	}

	public static void main(String[] args){
		new WindowHandleDemo();
	}

}