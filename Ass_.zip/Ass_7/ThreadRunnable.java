public class ThreadRunnable implements Runnable{
	
	@Override
	public void run(){
		System.out.println("I am from ThreadRunnable");
	}
}
