import java.awt.*;
import javax.swing.*;

class Q7 extends JPanel{
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		setBackground(Color.BLACK);

		g.setColor(Color.YELLOW);
		g.drawLine(30,40,100,200);
		g.drawOval(150,180,10,10);
		g.drawRect(200,210,20,30);

		g.setColor(Color.RED);
		g.fillOval(300,310,30,50);
		g.fillRect(400,350,60,50);

		g.setColor(Color.WHITE);
		g.setFont(new Font("MonoSpaced", Font.PLAIN,12));
		g.drawString("Testing custom drawing...", 10,20);

	}


	public static void main(String[] args){

		JFrame frm = new JFrame("First Graphics Test");
		Q7 fdm = new Q7();
		frm.add(fdm);
		frm.setSize(640,480);
		frm.setVisible(true);
	}
}