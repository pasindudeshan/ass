class Messenger{
	
	private String message;

	public void setMessage(String message){
		this.message = message;
	}


	public String getMessage(){
		return message;
	}
}

class Sender extends Thread{
	Messenger messenger;
	String message;

	public Sender(Messenger messenger, String message){
		this.messenger = messenger;
		this.message = message;
	}

	@Override
	public void run(){
		synchronized(this.messenger){
			System.out.println("Sending the message...");
			this.messenger.setMessage(this.message);
			
			this.messenger.notifyAll();

			System.out.println("Sending completed....");
		}
	}
}

class Reciever extends Thread{

	Messenger messenger;

	public Reciever(Messenger messenger){
		this.messenger = messenger;
	}

	@Override
	public void run(){
		synchronized(this.messenger){
			System.out.println("Waiting for Recieving....");
			try{
				this.messenger.wait();
			}
			catch(InterruptedException e){
				e.printStackTrace();
			}

			System.out.println("Recived Message: " + this.messenger.getMessage());

		}
	}
}

public class Q6{

	public static void main(String[] args){

		Messenger messenger = new Messenger();

		Sender sender = new Sender(messenger, "Hello World");
		Reciever reciever = new Reciever(messenger);

		
		reciever.start();
		sender.start();


	}
}