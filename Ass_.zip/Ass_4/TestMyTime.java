public class TestMyTime{
	public static void main(String[] args){
		MyTime myTime1 = new MyTime(23,59,59);
		MyTime myTime2 = new MyTime(10,59,59);
		MyTime myTime3 = new MyTime(10,30,59);
		MyTime myTime4 = new MyTime(10,30,30);
		
		System.out.println("-----Second next Methods-------");
		
		System.out.println(myTime1);
		System.out.println(myTime1.nextSecond() + "\n");
		
		System.out.println(myTime2);
		System.out.println(myTime2.nextSecond() +"\n");
		
		System.out.println(myTime3);
		System.out.println(myTime3.nextSecond() + "\n");
		
		System.out.println(myTime4);
		System.out.println(myTime4.nextSecond());
		
		
		System.out.println("\n-----Second previous Methods-------");
		
		System.out.println(myTime1);
		System.out.println(myTime1.previousSecond() + "\n");
		
		System.out.println(myTime2);
		System.out.println(myTime2.previousSecond() + "\n");
		
		System.out.println(myTime3);
		System.out.println(myTime3.previousSecond() + "\n");
		
		System.out.println(myTime4);
		System.out.println(myTime4.previousSecond());
		
		System.out.println("\n-----Minute next Methods-------");
		
		System.out.println(myTime1);
		System.out.println(myTime1.nextMinute() + "\n");
		
		System.out.println(myTime2);
		System.out.println(myTime2.nextMinute() + "\n");
		
		System.out.println(myTime3);
		System.out.println(myTime3.nextMinute() + "\n");
		
		System.out.println(myTime4);
		System.out.println(myTime4.nextMinute());
		
		
		System.out.println("\n-----Minute previous Methods-------");
		
		System.out.println(myTime1);
		System.out.println(myTime1.previousMinute() + "\n");
		
		System.out.println(myTime2);
		System.out.println(myTime2.previousMinute() + "\n");
		
		System.out.println(myTime3);
		System.out.println(myTime3.previousMinute() + "\n");
		
		System.out.println(myTime4);
		System.out.println(myTime4.previousMinute());
		
		System.out.println("\n-----Hour next Methods-------");
		
		System.out.println(myTime1);
		System.out.println(myTime1.nextHour() + "\n");
		
		System.out.println(myTime2);
		System.out.println(myTime2.nextHour() + "\n");
		
		System.out.println(myTime3);
		System.out.println(myTime3.nextHour() + "\n");
		
		System.out.println(myTime4);
		System.out.println(myTime4.nextHour());
		
		
		System.out.println("\n-----Hour previous Methods-------");
		
		System.out.println(myTime1);
		System.out.println(myTime1.previousHour() + "\n");
		
		System.out.println(myTime2);
		System.out.println(myTime2.previousHour() + "\n");
		
		System.out.println(myTime3);
		System.out.println(myTime3.previousHour() + "\n");
		
		System.out.println(myTime4);
		System.out.println(myTime4.previousHour());
	}
}