public class Q6 {

	public static void main(String[] args){
		SinThread thread1 = new SinThread(60);
		CosThread thread2 = new CosThread(60);
		TanThread thread3 = new TanThread(60);
		
		thread1.start();
		thread2.start();
		thread3.start();
		
		double p = thread1.sinValue() + thread2.cosValue() + thread3.tanValue();
		
		System.out.println(p);
	}
}
