public class Q1_i{
	
	public static void main(String[] args){
		int a = 500;
		int  c = 500/0;
		System.out.println("Answer : " + c);
		//ArithmeticException wil occur
	}
}