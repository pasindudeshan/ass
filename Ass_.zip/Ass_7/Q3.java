public class Q3 extends Thread {
	
	int[] intArray  = null;
	
	public void setIntArray(int[] intArray){
		this.intArray = intArray;
	}
	
	public void sumOfIntArray(){
		int sum = 0;
		for(int value : intArray){
			sum += value;
		}
		
		System.out.println("Sumammation of the array: " + sum);
	}
	
	
	@Override
	public void run(){
		sumOfIntArray(); //caling the method
	}
	
}
