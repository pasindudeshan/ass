
public class Calculator{
	int intResult;
	double doubleResult;
	
	class Adder{

		
		Adder(int num1, int num2){
			intResult = num1 + num2;
		}
		
		//method overloading
		Adder(double num1, double num2){
			doubleResult = num1 + num2;
		}
		
		Adder(){
			intResult = 0;
			doubleResult = 0;
		}
		
		int add(){
			return intResult;
		}
		
		int add(int num1, int num2){
			return num1 + num2;
		}
		
		double add(double num1,double num2){
			return num1 + num2;
		}
		
		
	}
	
	class Subtractor{
		
		Subtractor(int num1 , int num2 ){
			intResult = num1 - num2;
		}	
		
		Subtractor(double num1 , double num2 ){
			doubleResult = num1 - num2;
		}
		
		Subtractor(){
			intResult = 0;
			doubleResult = 0;
		}
		
		int subtract(){
			return intResult;
		}
		
		int subtract(int num1, int num2){
			return num1 - num2;
		}
		
		double subtract(double num1, double num2){
			return num1 - num2;
		}
		
	}
	
	class Multiplier{
		
		Multiplier(int num1, int num2){
			intResult = num1 * num2;
		}
		
		Multiplier(double num1, double num2){
			doubleResult = num1 * num2;
		}
		
		Multiplier(){
			intResult = 0;
			doubleResult = 0;
		}
		
		int multiply(){
			return intResult;
		}
		
		int multiply(int num1, int num2){
			return num1 * num2;
		}
		
		double multiply(double num1, double num2){
			return num1 * num2;
		}
	}
	
	class Divider{
		
		Divider(int num1, int num2){
			if(num2 != 0)
				intResult = num1 / num2;
		}
		
		Divider(double num1, double num2){
			if (num2 != 0)
				doubleResult = num1 / num2 ;
		}
		
		Divider(){
			intResult = 0;
			doubleResult = 0;
		}
		
		int divide(){
			return intResult;
		}
		
		int divide(int num1, int num2){
			if(num2 != 0)
				intResult = num1 / num2;
			return intResult;
		}
		
		double divide(double num1, double num2){
			if(num2 != 0)
				doubleResult = num1 / num2;
			return doubleResult;
		}
	}
	
}