import java.util.Scanner;

public class Q3{

	public static void main(String[] args){
		
		int x1, y1, x2, y2;
		double gradient ;
		
		Scanner input = new Scanner(System.in);
		while(true){
			try{
				System.out.println("Enter the Cordinate 1 : ");
				x1 = input.nextInt();
				y1 = input.nextInt();
				
				System.out.println("Enter the Cordinate 2: ");
				x2 = input.nextInt();
				y2 = input.nextInt();
				
				//usign wrapper class to convert to a double 
				//Or we can create a object and the convert to double
				//Double value = new Double (y2 -y1);
				gradient = Double.valueOf((y2 - y1)) /(x2 - x1) ;
				
				System.out.println("Gradient of the two points: " + gradient);
				break ;
			}
			catch(ArithmeticException e){
				System.out.println("Error!! " + e);
			}
		}
	}
}