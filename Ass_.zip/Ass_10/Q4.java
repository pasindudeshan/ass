import java.awt.*;
import javax.swing.*;
import java.awt.event.*;


class Q4 extends JFrame{
	
	private JLabel lbl;
	private JPanel pnl;

	public Q4(){

		this.lbl = new JLabel();
		this.pnl = new JPanel();

		this.pnl.setLayout(null);

		this.lbl.setBounds(0,0,100,60);
		this.lbl.setBackground(Color.BLACK);

		//if true the component paints every pixel within its bounds
		this.lbl.setOpaque(true);

		this.pnl.add(this.lbl);
		this.add(pnl);

		this.lbl.addMouseListener(new MouseListenerHandler(this.lbl));

		this.setSize(500,500);
		this.setVisible(true);
		this.setDefaultCloseOperation(3);
		
	}


	public static void main(String[] args){
		new Q4();
	}

}

class MouseListenerHandler implements MouseListener{

	private JLabel target;
	

	public MouseListenerHandler(JLabel target){
		this.target = target;
	}

	@Override
	public void mouseClicked(MouseEvent e){
		//setBackground or setForground
		this.target.setBackground(Color.YELLOW);
		this.target.setText("Pasindu");
	}

	@Override
	public void mousePressed(MouseEvent e){
				this.target.setBackground(Color.GREEN);
		this.target.setText("Deshan");	
	}

		@Override
	public void mouseReleased(MouseEvent e){

		this.target.setBackground(Color.CYAN);
		this.target.setText("Wijesiri");		
	}

		@Override
	public void mouseEntered(MouseEvent e){
		this.target.setBackground(Color.BLUE);
		this.target.setText("Gunawardana");
		
	}

		@Override
	public void mouseExited(MouseEvent e){

		this.target.setBackground(Color.MAGENTA); //setBackground or setForground
		this.target.setText("Finished");		
	}
}

