import java.util.Scanner;
import java.io.IOException;
import java.util.InputMismatchException;

public class Q9{
	
	static String getPort(int input) throws IOException{
		
		switch(input){
			
			case 20:
				return "FTP";
			
			case 22:
				return "SSH";
			
			case 25:
				return "SMTP" ;
			
			case 53 : 
				return "DNS";
				
			case 80 :
				return "HTTP";
			
			case 161:
				return "SNMP";
			
			default:
				throw new IOException("Invalid Port");
		}
	}
	
	
	static void getUserInputs(){
		try{
			try{
				Scanner input  = new Scanner(System.in);
				
				System.out.println("Enter Port value: ");
				int userInput = input.nextInt();
		
				String  message= getPort(userInput);
				System.out.println("Port is " + message);
			}catch(IOException e){
				System.out.println("Invalid Messege!!");
				e.printStackTrace();
			}
		}
		catch(InputMismatchException e){
			System.out.println("Invalid input port value type");
			e.printStackTrace();
		}
		
	}
	
	
	public static void main(String[] args){
		getUserInputs();
		
	}
}