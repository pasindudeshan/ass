public class SeriesCalculatorTest {

	public static void main(String[] args){
		
		
		SeriesCalculator thread1 = new SeriesCalculator(1,20);
		SeriesCalculator thread2 = new SeriesCalculator(21,40);
		SeriesCalculator thread3 = new SeriesCalculator(41,60);
		SeriesCalculator thread4 = new SeriesCalculator(61,80);
		SeriesCalculator thread5 = new SeriesCalculator(81, 100);
		
		try{
			thread1.start();
			thread1.join(); //join() method wait till the this thread to die
					//isAliver() method check check that current thread is alive
			thread2.start();
			thread2.join();
		
			thread3.start();
			thread3.join();
		
			thread4.start();
			thread4.join();
			
			thread5.start();
			thread5.join();
			
			System.out.println(thread1.getSummation());
			
			System.out.println(thread2.getSummation());
			System.out.println(thread3.getSummation());
			System.out.println(thread4.getSummation());
			System.out.println(thread5.getSummation());		
		}
		catch(InterruptedException e){
			e.printStackTrace();
		}
			
	}
}
