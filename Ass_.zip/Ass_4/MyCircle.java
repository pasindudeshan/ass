
public class MyCircle{
		
	private MyPoint center;
	private int radius ;
	
	public MyCircle(int x, int y, int radius){
		//center.setXY(x,y);  we can\t assign values to reffernce . if we initalize this way and use get methods to get values it will throw nullPointerExeception
		center = new MyPoint(x,y); //center is a reffernce values so first we need to create a instace to assign values
		//center.setXY(x,y); we can initalize them from the contructor or we can use setters to do it
		this.radius = radius;
		
	}
	public MyCircle(MyPoint center, int radius){
		this.center = center;
		this.radius = radius;
	}
	
	public int getRadius(){
		return radius;
	}
	
	public void setRadius(int radius){
		this.radius = radius;
	}
	
	public MyPoint getCenter(){
		return center;
	}
	
	public void setCenter(MyPoint center){
		this.center = center;
	}
	
	public int getCenterX(){
		return center.getX();
	}
	
	public int getCenterY(){
		return center.getY();
	}
	
	public void setCenterXY(int x, int y){
		center.setXY(x,y);
	}
	
	@Override
	public String toString(){
		return String.format("Circle @ (%d , %d) radius  =  %d", getCenterX(), getCenterY(), getRadius());
	}
	
	public double getArea(){
		
		return Math.PI * Math.pow(radius, 2);
	}
	
	
}