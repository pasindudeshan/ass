
public class Q8{

	public int sumOfIntArray(int[] arr){
		if(arr.length > 10){
			throw new ArrayIndexOutOfBoundsException("Array is to large");
		}
		else{
			int sum = 0;
			for(int value : arr){
				sum += value ;
			}
			
			return sum;
		}
	}
	
	
	public void functionTest(){
		int[] arr = {1,2,3,4,5,6,7,8,9 ,10,11};
		Q8 myObj = new Q8();
		System.out.println("Sum of the array: " + myObj.sumOfIntArray(arr));
	}
	
	public static void main(String[] args){
		Q8 myObj = new Q8();
		
		myObj.functionTest();
		
	}
}