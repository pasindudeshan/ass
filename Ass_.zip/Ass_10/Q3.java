import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class Q3 extends JFrame{
	
	private JLabel lbl1;
	private JButton btn1;
	private JButton btn2;
	private JPanel pnl;

	public Q3(){

		this.pnl = new JPanel();

		this.btn1 = new JButton("Show Message 1");
		this.btn2 = new JButton("Show Message 2");

		this.lbl1 = new JLabel("Message here", JLabel.CENTER);
		

		//add button to Panel
		pnl.add(btn1);
		pnl.add(btn2);

		//Add panel adn label to frame
		this.add(lbl1,BorderLayout.CENTER);
		this.add(pnl,BorderLayout.SOUTH);

		btn1.addActionListener(new LabelButtonHandler(lbl1,"Object Oriented Programming"));
		btn2.addActionListener(new LabelButtonHandler(lbl1, "Data Structures and Algorithms"));


		this.setSize(400,400);
		this.setVisible(true);
		this.setDefaultCloseOperation(3);

	}


	public static void main(String[] args){
		new Q3();
	}



}


class LabelButtonHandler implements ActionListener{

	private JLabel lbl;
	private String message;

	public LabelButtonHandler(JLabel lbl , String message){
		this.lbl = lbl;
		this.message = message;
	}

	@Override
	public void actionPerformed(ActionEvent ae){

		this.lbl.setText(this.message);
	}
}