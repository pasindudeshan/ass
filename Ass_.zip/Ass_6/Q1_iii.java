public class Q1_iii{
	
	public static void main(String[] args){
		
		String ptr = null;
		
		if(ptr.equals("hello")){
			System.out.println("Same");
		}
		else{
			System.out.println("Not Same");
		}
		//no value is assign to ptr so
		//NullPointerException gets occur
	}
}