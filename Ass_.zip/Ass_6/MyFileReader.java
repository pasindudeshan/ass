
import java.io.*;

class MyFileReader{
	
	//Two Exceptions need to be caught
	//FileNotFoundException
	//IOException
	
	public static void main(String[] args){
		try{
			String line;
			BufferedReader br = new BufferedReader(new FileReader("ExceptionCheck.txt")) ;
			
			try{
				while((line = br.readLine()) != null){
					System.out.println(line);
				}
			}
			catch(IOException e){
				System.out.println("Error!! " + e);
			}
		}
		catch(FileNotFoundException e){
			System.out.println("Error!! " + e);
		}
	}
}