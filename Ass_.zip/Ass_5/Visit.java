import java.util.Date;

public class Visit{

	private Customer customer;
	private Date date;
	private double serviceExpense ;
	
	public Visit(String name, String memberType, Date date){
		this.customer = new Customer(name);
		this.customer.setMemberType(memberType);
		this.date = date;
	}	
	
	public double getServiceExpense(){
		return this.serviceExpense;
	}
	
	public void setServiceExpense(double serviceExpense){
		this.serviceExpense = serviceExpense;
	}
	
	public double getTotalExpense(){
		return this.serviceExpense - (this.serviceExpense * Discount.getServiceDiscountRate(this.customer.getMemberType()));
	}
	
}
