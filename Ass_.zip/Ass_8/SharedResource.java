class SharedResource{

	private int[] source_array;

	public SharedResource(int size){
		this.source_array = new int[size];
	}

	public void writeValue(){

		for(int i = 0; i < source_array.length ; i++){
			source_array[i] = (i+1) * 5;
			System.out.println(Thread.currentThread().getName() + " Element "+ i + ":" + source_array[i]);
		}
	}

	public void readValue(){

		for(int r = 0 ; r < source_array.length ; r++){
			System.out.println(Thread.currentThread().getName() + " Element " + r + ":" + source_array[r]);
		}
	}
}

class ArrayWriter extends Thread{

	SharedResource sharedResouce;

	public ArrayWriter(SharedResource sharedResouce){
		this.sharedResouce = sharedResouce;
	}

	@Override
	public void run(){
		sharedResouce.run(); //ArrayWriter class run method will execute in the thread
	}


}

class ArrayReader extends Thread{

	SharedResource	sharedResouce;

	public ArrayReader(SharedResource sharedResouce){

		this.sharedResouce = sharedResouce;
	}

	@Override
	public void run(){
		sharedResouce.readValue();
	}
}

public class ArrayReaderWriter(){

	public static void main(String[] args){
		SharedResource sharedResouce = new SharedResource(10);

		//create ArrayWriter Thread object	
		ArrayWriter arrayWriter = new ArrayWriter(sharedResouce);

		//starting the thread of ArrayWriter
		arrayWriter.start();

		//create ArrayReader Thread Object
		ArrayReader arrayReader = new ArrayReader(sharedResouce);
		ArrayReader.start();

	}
}