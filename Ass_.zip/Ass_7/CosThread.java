public class CosThread extends Thread{
	
	private double degrees;
	private double radians;
	
	public CosThread(double degrees){
		this.degrees = degrees;
	}
	
	public double cosValue(){
	
		return radians;
	}
	
	@Override
	public void run(){
		radians =  Math.cos(Math.toRadians(degrees));
		if(isAlive()){
			System.out.println("Thread is Alive");
			
			
		}

	}
}
