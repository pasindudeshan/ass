import java.awt.*;
import javax.swing.*;

public class Q8_ii extends JPanel{
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);


	

		int x = 10, y = 0;
		

		for(int i = 0 ; i < 20 ; i++){
			g.setColor(Color.BLACK);
			g.drawRect(0,y,x,10);

			g.setColor(Color.RED);
			g.fillRect(0,y,x,9);
			x+=10;
			y+=10;
		}




	}


	public static void main(String[] args){

		JFrame frm = new JFrame();
		Q8_ii pnl = new Q8_ii();

		frm.add(pnl);

		frm.setSize(450,450);
		frm.setVisible(true);
		frm.setDefaultCloseOperation(frm.EXIT_ON_CLOSE);

	}
}