
public class TestBook{
	
	public static void main(String[] args){
	
	Author[] authors = new Author[3];
	
	authors[0] = new Author("Kumarathunga Munidasa",  "kumarathungamunidasa@gmail.com", 'm');
	authors[1] = new Author("Martin Wikramasinghe",  "martinwikramasinghe@gmail.com", 'm');
	authors[2] = new Author("Ediriweera Sarchchandra",  "ediriweerasarchchandra@gmail.com", 'm');
	
	Book book = new Book("Madol Duuwa", authors, 750, 2);
	book.printAuthors();
	
	System.out.println(book.getName());
	//this return a author array so to print we need to iterate through array or print by using indicies
	System.out.println(book.getAuthor()[1]);
	System.out.println(book.getPrice());
	System.out.println(book.getQtyInStock());
	
	
	System.out.println(book);
	
	
	
	
	}
}