public class TanThread extends Thread{
	private double degrees;
	private double radians;
	
	public TanThread(double degrees){
		this.degrees = degrees;
	}
	
	public double tanValue(){
	
		return radians;
	}
	
	@Override
	public void run(){
		radians =  Math.tan(Math.toRadians(degrees));
		if(isAlive()){
			System.out.println("Thread is Alive");
			
			
		}

	}
}
