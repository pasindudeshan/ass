
class NestedExceptionTes{
	
	public static void main(String[] args){
		try{
			
			try{
				//int a = Integer.parseInt("e"); //Caught Outside
				//int a = Integer.parseInt("63");
				int a = Integer.parseInt("63") /0; //Caught Inside
			}
			catch(ArithmeticException e){
				System.out.println("Caught inside");
				e.printStackTrace();
			}
		}
		catch(NumberFormatException e){
			System.out.println("Caught outside");
			e.printStackTrace();
		}
		
	}
}