public class Q3Test{

	public static void main(String[] args){

		Q3 q3Test1 = new Q3();
		Q3 q3Test2 = new Q3();
		Q3 q3Test3 = new Q3();
		
		int[] class_A = {23, 45, 12, 67 , 34};
		q3Test1.setIntArray(class_A);

		
		long start_time = System.nanoTime(); //nanotime get the system current time
		
		q3Test1.start(); //starting the thread
		
		long end_time = System.nanoTime();
		
		System.out.println("Time taken to complete the task: " + (end_time - start_time));
		
		int[] class_B = {50, 34, 12, 90, 123, 19};
		q3Test2.setIntArray(class_B);
		
		start_time = System.nanoTime(); //nanotime get the system current time
		q3Test2.start(); //starting the thread
		end_time = System.nanoTime();
		
		System.out.println("Time taken to complete the task: " + (end_time - start_time));		

		int[] class_C = {45, 34, 78, 99, 22, 55, 66 , 77 , 90};
		q3Test3.setIntArray(class_C);
		
		start_time = System.nanoTime(); //nanotime get the system current time
		
		q3Test3.start(); //starting the thread
		
		end_time = System.nanoTime();
		
		System.out.println("Time taken to complete the task: " + (end_time - start_time));
	}
}
