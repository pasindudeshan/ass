class HTMLTag {
	
	public void lineA(){
		System.out.println("**************************************************");
		System.out.println("<Name> Object Oriented Programming </Name>");
		System.out.println("**************************************************");
	}

	public void lineB(){
		System.out.println("**************************************************");
		System.out.println("<Course> CSC2123 </Course>");
		System.out.println("**************************************************");
	}

	public void lineC(){
		System.out.println("**************************************************");
		System.out.println("<University>University of Ruhuna </University>");
		System.out.println("**************************************************");
	}

	public void lineD(){
		System.out.println("**************************************************");
		System.out.println("<Department> Department Of Computer Science</Department>");
		System.out.println("**************************************************");
	}
}

class A extends Thread{
	
	HTMLTag tag;

	public A(HTMLTag tag){
		this.tag = tag;
	}

	@Override
	public void run(){
		tag.lineA();
	}	

}

class B extends Thread{
	
	HTMLTag tag;

	public B(HTMLTag tag){
		this.tag = tag;
	}

	@Override
	public void run(){
		tag.lineB();
	}	

}

class C extends Thread{
	
	HTMLTag tag;

	public C(HTMLTag tag){
		this.tag = tag;
	}

	@Override
	public void run(){
		tag.lineC();
	}	

}

class D extends Thread{
	
	HTMLTag tag;

	public D(HTMLTag tag){
		this.tag = tag;
	}

	@Override
	public void run(){
		tag.lineD();
	}	

}


public class Q4{
	
	public static void main(String[] args){
		HTMLTag tag = new HTMLTag();

		A tagA = new A(tag);
		B tagB = new B(tag);
		C tagC = new C(tag);
		D tagD = new D(tag);

		synchronized(tagA)
		{
			tagA.start();
		}

		synchronized(tagB)
		{
			tagB.start();
		}

		synchronized(tagC)
		{
			tagC.start();
		}

		synchronized(tagD)
		{
			tagD.start();
		}
		

	}
}