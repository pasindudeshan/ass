
public class TestCalculator{
	
	public static void main(String[] args){
		
		
		Calculator cal = new Calculator();
		
		System.out.println("------------Addition------------");
		Calculator.Adder result = cal.new Adder(3,4);
		
		System.out.println(result.add());
		
		//we can call a method from calling the constructor and then use . to call the relavant method to call the method
		double result2 = cal.new Adder().add(8.8, 2.3);
		System.out.println(result2);
		
		//Subtraction
		
		System.out.println("\n------------Subtraction------------");
		Calculator.Subtractor result3 = cal.new Subtractor(3,4);
		
		System.out.println(result3.subtract());
		

		double result4 = cal.new Subtractor().subtract(8.8, 2.3);
		System.out.println(result4);


		//Multiplication
		System.out.println("\n------------Multiplication------------");
		Calculator.Multiplier result5 = cal.new Multiplier(3,4);
		
		System.out.println(result5.multiply());

		double result6 = cal.new Multiplier().multiply(8.8, 2.3);
		System.out.println(result6);
		
		//Division
		System.out.println("\n------------Division------------");
		Calculator.Divider result7 = cal.new Divider(4,3);
		
		System.out.println(result7.divide());

		double result8 = cal.new Divider().divide(8.8, 2.3);
		System.out.println(result8);
	}
}