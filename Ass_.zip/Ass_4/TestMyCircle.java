
public class TestMyCircle{

	public static void main(String[] args){
		
		MyCircle myPoint1 = new MyCircle(4,5,7);
		System.out.println("Point x: " + myPoint1.getCenter().getX());
		System.out.println("Distance from(8, 8) to center : " + myPoint1.getCenter().distance(8,8));
		
		System.out.println(myPoint1);
		System.out.println("Area: " + myPoint1.getArea());
		
		//change the center values
		myPoint1.setCenterXY(8, 9);
		System.out.println(myPoint1);
		
	
	}
}