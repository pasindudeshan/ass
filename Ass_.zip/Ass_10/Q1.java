import java.awt.*;
import javax.swing.*;

class Q1 extends Canvas{

	@Override
	public void paint(Graphics g){
		g.setColor(Color.RED);
		g.fillOval(50,50,200,200);

		g.setColor(Color.GREEN);
		g.fillOval(150,50,200,200);
		
		g.setColor(Color.BLUE);
		g.fillOval(100,150,200,200);
	}

	public static void main(String[] args){

		JFrame frm = new JFrame("Circle on Canvas");

		Q1 canvas = new Q1();

		frm.add(canvas);
		frm.setSize(400,400);
		frm.setVisible(true);
		frm.setLocationRelativeTo(null);
		frm.setDefaultCloseOperation(frm.EXIT_ON_CLOSE);
	}
}