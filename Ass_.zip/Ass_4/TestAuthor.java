
public class TestAuthor{
	
	public static void main(String[] args){
		Author author = new Author("Kumarathunga Munidasa",  "kumarathungamunidasa@gmail.com", 'm');
		System.out.println(author);
		
		System.out.println("Name: " + author.getName());
		System.out.println("Email: " + author.getEmail());
		
		//set to new email
		author.setEmail("kumarathungamunidasa123@gmail.com");
		System.out.println("Name: " + author.getEmail());
		
		System.out.println("Gender: " + author.getGender());
		
		
	}
}