public class NamedThread extends Thread{
	
	public NamedThread(String name){
		//Allocates a new thread Object
		super(name) ; //calling the super class consturctor
	}
	
	@Override
	public void run(){
		for(int i = 0 ; i < 6 ; i++){
			System.out.println(i + " " + getName()); //getName return thread name
		}
	}
	
	
	public static void main(String[] args){
		
		NamedThread thread1 = new NamedThread("one");
		NamedThread thread2 = new NamedThread("two");
		
		thread1.start();
		thread2.start();
	}
}
