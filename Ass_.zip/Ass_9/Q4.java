import java.awt.*;
import java.awt.event.*;

//CheckBox Demo
class Q4{
	
	public Q4(){

		Frame frm = new Frame("CheckBox Setting");

		frm.addWindowListener(
			new WindowAdapter(){
				@Override
				public void windowClosing(WindowEvent we){
					frm.dispose();
				}
			}
		);

		Panel pn1 = new Panel();

		Label food_pre = new Label("Programming Language");

	/*	Checkbox chk_java = new Checkbox("Java", true); // true indicate that it is checked by default
		Checkbox chk_c = new Checkbox("C", false);
		Checkbox chk_c_plus = new Checkbox("C++", false);
		Checkbox chk_python = new Checkbox("Python", false);
		Checkbox chk_php = new Checkbox("PHP", false);
	*/

		CheckboxGroup group_language = new CheckboxGroup();

		Checkbox chk_java = new Checkbox("Java",group_language , false); // we can pass three arguments so we can group the check box
		Checkbox chk_c = new Checkbox("C",group_language , false);
		Checkbox chk_c_plus = new Checkbox("C++",group_language , false);
		Checkbox chk_python = new Checkbox("Python",group_language , true);
		Checkbox chk_php = new Checkbox("PHP",group_language , false);



		pn1.add(food_pre);
		pn1.add(chk_java);
		pn1.add(chk_c);
		pn1.add(chk_c_plus);
		pn1.add(chk_python);
		pn1.add(chk_php);

		frm.add(pn1);

		frm.setSize(400,400);
		frm.setVisible(true);
	}


	public static void main(String[] args){

		new Q4();
	}
}