import java.awt.*;
import javax.swing.*;

public class Q8_i extends JPanel{
	
	@Override
	public void paintComponent(Graphics g){
		super.paintComponent(g);

		setBackground(Color.BLACK);

		Color[] cir_cols = {Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.ORANGE, Color.PINK};

		int x = 20, y = 30;

		for(Color c : cir_cols){
			g.setColor(c);
			g.fillOval(x,y,80,80);
			x+=40;
			y+=40;
		}

		x = 20;
		y = 300;

		for(Color c : cir_cols){
			g.setColor(c);
			g.fillOval(x,y,80,80);
			x+=40;
			y-=40;
		}




	}


	public static void main(String[] args){

		JFrame frm = new JFrame();
		Q8_i pnl = new Q8_i();

		frm.add(pnl);

		frm.setSize(450,450);
		frm.setVisible(true);
		frm.setDefaultCloseOperation(frm.EXIT_ON_CLOSE);

	}
}