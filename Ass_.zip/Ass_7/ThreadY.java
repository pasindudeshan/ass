class ThreadY extends Thread{

	public void run()
	{
		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
		}
	}

}

class ThreadLive{

	public static void main(String[] args)
	{
		ThreadY target=new ThreadY();
		ThreadX source=new ThreadX(target);
	}
}
