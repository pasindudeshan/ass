import java.util.Scanner;


class Account{

	private double balance;

	public  Account(double balance){
		this.balance = balance;
	}

	public double getBalance(){
		return this.balance;
	}

	
	public void deposit(double amount){
		this.balance += amount;

	}	

	public void withdraw(double amount){

		if(amount > this.balance){
			throw new RuntimeException("Insufficient Balance!!!");
		}
		else{
			this.balance -= amount;
			System.out.println("\nYour Account balance: "+ getBalance());
		}
	}
}

class Deposit extends Thread{

	Account account;
	double amount ;

	public Deposit(Account account){
		this.account = account;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Deposit amount: ");
		amount  = input.nextDouble();
	}

	@Override
	public void run(){


		synchronized(account){
			account.deposit(this.amount);
			System.out.println("\nYour Account balance: "+ this.account.getBalance());
		}

	}
}

class Withdraw extends Thread{

	Account account;
	double amount;

	public Withdraw(Account account){
		this.account = account;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter Withdraw amount: ");
		amount  = input.nextDouble();
	}

	@Override
	public void run(){



		account.withdraw(this.amount);


	}
}


public class Q3{

	public static void main(String[] args){

		Account newAccount = new Account(2000);

		Deposit deposit = new Deposit(newAccount);
		Withdraw withdraw = new Withdraw(newAccount);

		deposit.start();
		withdraw.start();
		try{
			deposit.join();
			withdraw.join();
		}
		catch(InterruptedException e){
			e.printStackTrace();
		}
		

	}

}