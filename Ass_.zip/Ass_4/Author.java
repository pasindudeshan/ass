

public class Author{
	
	private String name;
	private String email;
	private char gender;
	
	//no default constructor
	
	//Constructor for Author class
	public Author(String name, String email, char gender){
		
		this.name = name ;
		this.email = email ;
		if(gender == 'm' || gender == 'f')
			this.gender= gender;
		else{
			//Actually need to do throw an exception 
			System.out.println("Error!!!");
			System.exit(0);
		}
	}
	
	public String getName(){
		return name;
	}
	
	public String getEmail(){
		
		return email;
	}
	
	public void setEmail(String email){
		this.email = email;
	}
	
	public char getGender(){
		return gender;
	}
	
	@Override
	public String toString(){
			return String.format("%s (%c) %s", getName(), getGender(), getEmail());
	}
}